libcamera-vid -t 0 --width 1920 --height 1080  --codec h264 -q 100 --inline --hflip --vflip --listen -o tcp://0.0.0.0:8888
